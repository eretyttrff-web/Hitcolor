# ShieldTap — Fabric 1.21.11

This safe starter build provides an F8 toggle and a small on-screen notice when a **manual** hit targets a player who is currently blocking with a shield. It does not automate attacks or switch combat items.

## Build

Requires Java 21 and Gradle 8. Use:

```bash
gradle build
```

The remapped mod JAR will be created in `build/libs/`.

## Install

Copy the built `shieldtap-1.0.0.jar` into the Minecraft instance's `mods` folder. Install Fabric Loader and Fabric API for Minecraft 1.21.11 as well.

## Keybind

- F8: toggle ShieldTap ON/OFF

The project uses Fabric's official Mojang mappings for Minecraft 1.21.11.
