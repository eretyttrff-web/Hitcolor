package com.example.shieldtap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class ShieldTapClient implements ClientModInitializer {
    private static KeyMapping toggleKey;
    private static boolean enabled = true;
    private static int noticeTicks = 0;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.shieldtap.toggle",
                GLFW.GLFW_KEY_F8,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            Component.literal("ShieldTap: " + (enabled ? "ON" : "OFF")), true);
                }
            }
            if (noticeTicks > 0) noticeTicks--;
        });
    }

    public static boolean isEnabled() { return enabled; }

    public static void showShieldNotice(Minecraft client) {
        if (client.player != null) {
            client.player.displayClientMessage(Component.literal("Shielding player detected"), true);
            noticeTicks = 30;
        }
    }
}
