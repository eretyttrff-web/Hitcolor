package com.example.shieldtap.mixin;

import com.example.shieldtap.ShieldTapClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "attack", at = @At("HEAD"))
    private void shieldtap$onManualAttack(net.minecraft.world.entity.player.Player player,
                                         Entity target, CallbackInfo ci) {
        if (!ShieldTapClient.isEnabled()) return;
        if (target instanceof net.minecraft.world.entity.player.Player
                && target instanceof LivingEntity living && living.isBlocking()) {
            ShieldTapClient.showShieldNotice(Minecraft.getInstance());
        }
    }
}
